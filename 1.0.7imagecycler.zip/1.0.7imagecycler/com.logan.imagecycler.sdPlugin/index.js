/**
 * Image Cycler Property Inspector
 * Copyright (c) 2025 Logan
 */

const $local = false, $back = false,
$dom = {
  main: $('.sdpi-wrapper'),
  imageCount: $('#imageCount'),
  mode: $('#mode'),
  flashOptions: $('#flashOptions'),
  flashSpeed: $('#flashSpeed'),
  restoreOnStop: $('#restoreOnStop'),
  repeatHotkey: $('#repeatHotkey'), // New
  
  // Image 2
  file2: $('#file2'),
  btnChoose2: $('#btn_choose2'),
  btnEdit2: $('#btn_edit2'),
  img2Preview: $('#img2_preview'),
  
  // Image 3
  image3Section: $('#image3Section'),
  file3: $('#file3'),
  btnChoose3: $('#btn_choose3'),
  btnEdit3: $('#btn_edit3'),
  img3Preview: $('#img3_preview'),

  // Hotkey
  hotkeyInput: $('#hotkeyInput'),
  clearHotkey: $('#clearHotkey'),
  hotkeyHoldTime: $('#hotkeyHoldTime'), // New
  
  // Editor
  editorOverlay: $('#editorOverlay'),
  editorCanvas: $('#editorCanvas'),
  sliderZoom: $('#sliderZoom'),
  sliderX: $('#sliderX'),
  sliderY: $('#sliderY'),
  btnSaveEdit: $('#btnSaveEdit'),
  btnCancelEdit: $('#btnCancelEdit')
};

// Editor State
let currentEditingTarget = null; // 'image2' or 'image3'
let currentEditImage = new Image();
let editorCtx = $dom.editorCanvas.getContext('2d');

$propEvent = {
  didReceiveSettings() {
    if ($settings.imageCount) {
      $dom.imageCount.value = $settings.imageCount;
      $dom.image3Section.style.display = $settings.imageCount === '3' ? 'block' : 'none';
    }
    if ($settings.mode) {
      $dom.mode.value = $settings.mode;
      $dom.flashOptions.style.display = $settings.mode === 'flash' ? 'block' : 'none';
    }
    if ($settings.flashSpeed) $dom.flashSpeed.value = $settings.flashSpeed;
    
    // Set Dropdowns (convert bool to string)
    $dom.restoreOnStop.value = $settings.restoreOnStop ? "true" : "false";
    $dom.repeatHotkey.value = ($settings.repeatHotkey !== false) ? "true" : "false";

    // Init Previews
    if ($settings.image2) {
      $dom.img2Preview.src = $settings.image2;
      $dom.btnEdit2.style.display = 'block';
    }
    if ($settings.image3) {
      $dom.img3Preview.src = $settings.image3;
      $dom.btnEdit3.style.display = 'block';
    }

    updateHotkeyDisplay($settings.hotkey);
    $dom.hotkeyHoldTime.value = $settings.hotkeyHoldTime || 0;
    $dom.main.style.display = 'block';
  }
};

// --- Image Handling ---

function handleFileSelect(file, target) {
  const reader = new FileReader();
  reader.onload = (e) => {
    openEditor(e.target.result, target);
  };
  reader.readAsDataURL(file);
}

function openEditor(imageSrc, target) {
  currentEditingTarget = target;
  currentEditImage = new Image();
  currentEditImage.onload = () => {
    // Reset sliders
    $dom.sliderZoom.value = 1.0;
    $dom.sliderX.value = 0;
    $dom.sliderY.value = 0;
    drawEditor();
    $dom.editorOverlay.style.display = 'flex';
  };
  currentEditImage.src = imageSrc;
}

function drawEditor() {
  const ctx = editorCtx;
  const canvas = $dom.editorCanvas;
  const width = canvas.width;
  const height = canvas.height;
  
  const zoom = parseFloat($dom.sliderZoom.value);
  const panX = parseInt($dom.sliderX.value);
  const panY = parseInt($dom.sliderY.value);

  // Clear background
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, width, height);

  ctx.save();
  
  // Move to center
  ctx.translate(width/2 + panX, height/2 + panY);
  ctx.scale(zoom, zoom);
  
  // Draw image centered
  ctx.drawImage(currentEditImage, -currentEditImage.width/2, -currentEditImage.height/2);
  
  ctx.restore();
}

$dom.sliderZoom.on('input', drawEditor);
$dom.sliderX.on('input', drawEditor);
$dom.sliderY.on('input', drawEditor);

$dom.btnCancelEdit.on('click', () => {
  $dom.editorOverlay.style.display = 'none';
});

$dom.btnSaveEdit.on('click', () => {
  const base64 = $dom.editorCanvas.toDataURL('image/png');
  
  if (currentEditingTarget === 'image2') {
    $settings.image2 = base64;
    $dom.img2Preview.src = base64;
    $dom.btnEdit2.style.display = 'block';
  } else if (currentEditingTarget === 'image3') {
    $settings.image3 = base64;
    $dom.img3Preview.src = base64;
    $dom.btnEdit3.style.display = 'block';
  }
  
  $websocket.sendToPlugin(JSON.parse(JSON.stringify($settings)));
  $dom.editorOverlay.style.display = 'none';
});

// Image 2 Controls
$dom.btnChoose2.on('click', () => $dom.file2.click());
$dom.file2.on('change', (e) => {
  if (e.target.files[0]) handleFileSelect(e.target.files[0], 'image2');
});
$dom.btnEdit2.on('click', () => {
  if ($settings.image2) openEditor($settings.image2, 'image2');
});

// Image 3 Controls
$dom.btnChoose3.on('click', () => $dom.file3.click());
$dom.file3.on('change', (e) => {
  if (e.target.files[0]) handleFileSelect(e.target.files[0], 'image3');
});
$dom.btnEdit3.on('click', () => {
  if ($settings.image3) openEditor($settings.image3, 'image3');
});


// --- Standard Settings ---

function updateHotkeyDisplay(hotkey) {
  if (hotkey && hotkey.key) {
    let parts = [];
    if (hotkey.ctrl) parts.push('Ctrl');
    if (hotkey.alt) parts.push('Alt');
    if (hotkey.shift) parts.push('Shift');
    parts.push(hotkey.key.toUpperCase());
    $dom.hotkeyInput.value = parts.join(' + ');
  } else {
    $dom.hotkeyInput.value = '';
  }
}

let recording = false;
$dom.hotkeyInput.on('click', () => {
  recording = true;
  $dom.hotkeyInput.value = 'Press keys...';
  $dom.hotkeyInput.classList.add('recording');
});

$dom.hotkeyInput.on('blur', () => {
  recording = false;
  $dom.hotkeyInput.classList.remove('recording');
  updateHotkeyDisplay($settings.hotkey);
});

$dom.hotkeyInput.on('keydown', (e) => {
  if (!recording) return;
  e.preventDefault();
  if (['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) return;
  
  let key = e.code.replace('Key', '').replace('Digit', '');
  key = key.replace('Left', '').replace('Right', '');
  
  $settings.hotkey = {
    key: key,
    ctrl: e.ctrlKey,
    alt: e.altKey,
    shift: e.shiftKey
  };
  updateHotkeyDisplay($settings.hotkey);
  $websocket.sendToPlugin(JSON.parse(JSON.stringify($settings)));
  $dom.hotkeyInput.blur();
});

$dom.clearHotkey.on('click', () => {
  $settings.hotkey = null;
  updateHotkeyDisplay(null);
  $websocket.sendToPlugin(JSON.parse(JSON.stringify($settings)));
});

$dom.hotkeyHoldTime.on('input', (e) => {
  $settings.hotkeyHoldTime = parseInt(e.target.value) || 0;
  $websocket.sendToPlugin(JSON.parse(JSON.stringify($settings)));
});

$dom.imageCount.on('change', (e) => {
  $settings.imageCount = e.target.value;
  $dom.image3Section.style.display = e.target.value === '3' ? 'block' : 'none';
  $websocket.sendToPlugin(JSON.parse(JSON.stringify($settings)));
});

$dom.mode.on('change', (e) => {
  $settings.mode = e.target.value;
  $dom.flashOptions.style.display = e.target.value === 'flash' ? 'block' : 'none';
  $websocket.sendToPlugin(JSON.parse(JSON.stringify($settings)));
});

$dom.flashSpeed.on('input', (e) => {
  $settings.flashSpeed = e.target.value;
  $websocket.sendToPlugin(JSON.parse(JSON.stringify($settings)));
});

$dom.restoreOnStop.on('change', (e) => {
  $settings.restoreOnStop = e.target.value === "true";
  $websocket.sendToPlugin(JSON.parse(JSON.stringify($settings)));
});

$dom.repeatHotkey.on('change', (e) => {
  $settings.repeatHotkey = e.target.value === "true";
  $websocket.sendToPlugin(JSON.parse(JSON.stringify($settings)));
});